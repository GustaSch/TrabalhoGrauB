package Trabalho;

public class Cliente {

	    public String nome;

		// Aqui foi criado um construtor 

	    public Cliente(String nome) {
	        this.nome = nome;
	    }

	    // Aqui foi criado os gets e sets

	    public String getNome() {
	        return nome;
	    }

	    public void setNome(String nome) {
	        this.nome = nome;
	    }
	}

